# BrewLoyal — Cafe Loyalty SaaS Starter

BrewLoyal is a multi-cafe digital loyalty starter: customer registration, QR-based staff workflow, 5-stamp reward logic, and a premium mobile-first landing page.

## Current scope
- Landing page and demo routes
- Customer registration form per cafe slug
- Supabase schema for cafes, customers, staff, loyalty transactions
- Staff QR scanner component
- Database RPC that restricts stamp issuance to authenticated staff belonging to the cafe
- Starter visual design

## Not production-ready yet
This is a development starter, not a finished commercial SaaS. The staff scanner currently needs an authenticated staff session; build the staff login/provisioning flow before using it. The demo route is not an authentication bypass. Customer QR display, reward redemption UI, tenant owner dashboard, subscription billing, WhatsApp API jobs, and location/geofencing still need implementation and testing. Do not expose customer records publicly.

## Run from GitHub Codespaces / Termux
1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Copy `.env.example` to `.env.local` and fill Supabase URL and anon key.
4. Install Node.js 20+.
5. Run:
   ```bash
   npm install
   npm run dev
   ```
6. Open the forwarded port 3000.

## Add a demo cafe
After running the schema, insert:
```sql
insert into public.cafes(name,slug) values ('Demo Cafe','demo-cafe');
```

## Required before selling
- Implement owner onboarding and authenticated staff login.
- Add customer QR generation and a customer wallet page.
- Add explicit redemption flow and idempotency protection.
- Add server-side customer registration validation, rate limiting, and abuse prevention.
- Verify Supabase RLS policies with separate cafe accounts.
- Add WhatsApp Business Platform integration using approved templates and opt-in records.
- Add scheduled birthday jobs and notification logs.
- Add subscription/payment provider and plan limits.
- Add backups, monitoring, privacy policy, terms, and Indonesian PDP compliance review.
- Test on real Android devices and production hosting.

## WhatsApp and proximity notes
WhatsApp messages require an official WhatsApp Business Platform provider, customer opt-in, approved templates where applicable, and server-side secrets. A website cannot reliably detect a customer walking past a cafe while closed; background geofencing generally requires a supported mobile app and explicit location permission.
