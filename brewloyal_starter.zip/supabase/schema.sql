-- BrewLoyal multi-cafe starter schema
create extension if not exists pgcrypto;

create table if not exists public.cafes (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 slug text unique not null,
 active boolean not null default true,
 created_at timestamptz not null default now()
);

create table if not exists public.customers (
 id uuid primary key default gen_random_uuid(),
 cafe_id uuid not null references public.cafes(id) on delete cascade,
 name text not null,
 whatsapp text not null,
 birth_date date,
 favorite_drink text not null,
 whatsapp_consent boolean not null default false,
 stamps integer not null default 0 check (stamps between 0 and 4),
 created_at timestamptz not null default now(),
 unique(cafe_id, whatsapp)
);

create table if not exists public.loyalty_transactions (
 id uuid primary key default gen_random_uuid(),
 cafe_id uuid not null references public.cafes(id) on delete cascade,
 customer_id uuid not null references public.customers(id) on delete cascade,
 action text not null check(action in ('stamp','redeem')),
 created_at timestamptz not null default now(),
 idempotency_key text unique
);

create table if not exists public.staff_members (
 id uuid primary key references auth.users(id) on delete cascade,
 cafe_id uuid not null references public.cafes(id) on delete cascade,
 role text not null default 'staff' check(role in ('owner','staff')),
 created_at timestamptz not null default now()
);

alter table public.cafes enable row level security;
alter table public.customers enable row level security;
alter table public.loyalty_transactions enable row level security;
alter table public.staff_members enable row level security;

-- Public registration may read active cafe details only.
create policy "public can view active cafe" on public.cafes for select using (active = true);
-- Customer self-registration: insert only; customer reads must be mediated by a secure server route.
create policy "public customer registration" on public.customers for insert with check (whatsapp_consent in (true,false));
-- Staff can read records belonging to their cafe.
create policy "staff read own cafe customers" on public.customers for select using (
 exists(select 1 from public.staff_members s where s.id=auth.uid() and s.cafe_id=customers.cafe_id)
);
create policy "staff read own transactions" on public.loyalty_transactions for select using (
 exists(select 1 from public.staff_members s where s.id=auth.uid() and s.cafe_id=loyalty_transactions.cafe_id)
);
create policy "staff read own membership" on public.staff_members for select using (id=auth.uid());

-- Server-side RPC: only authenticated staff assigned to the same cafe may issue stamps.
create or replace function public.issue_loyalty_stamp(p_customer_id uuid,p_cafe_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare c public.customers%rowtype; next_count integer;
begin
 if auth.uid() is null or not exists(
   select 1 from public.staff_members s where s.id=auth.uid() and s.cafe_id=p_cafe_id
 ) then raise exception 'Unauthorized staff'; end if;
 select * into c from public.customers where id=p_customer_id and cafe_id=p_cafe_id for update;
 if not found then raise exception 'Customer not found'; end if;
 if c.stamps >= 4 then
   update public.customers set stamps=0 where id=c.id;
   insert into public.loyalty_transactions(cafe_id,customer_id,action) values(p_cafe_id,c.id,'stamp');
   insert into public.loyalty_transactions(cafe_id,customer_id,action) values(p_cafe_id,c.id,'redeem');
   return jsonb_build_object('message','Reward unlocked! 5/5 stamps — free favorite drink: '||c.favorite_drink,'reward',true,'stamps',0);
 else
   next_count:=c.stamps+1;
   update public.customers set stamps=next_count where id=c.id;
   insert into public.loyalty_transactions(cafe_id,customer_id,action) values(p_cafe_id,c.id,'stamp');
   return jsonb_build_object('message','Stamp added: '||next_count||'/5','reward',false,'stamps',next_count);
 end if;
end; $$;
revoke all on function public.issue_loyalty_stamp(uuid,uuid) from public, anon;
grant execute on function public.issue_loyalty_stamp(uuid,uuid) to authenticated;

-- IMPORTANT: Before production, tighten policies with server-side registration,
-- authenticated staff provisioning, rate limits, audit logs, and verified cafe ownership.
