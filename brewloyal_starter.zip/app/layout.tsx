import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "BrewLoyal — Cafe Loyalty", description: "Digital loyalty system for cafes" };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="id"><body>{children}</body></html>;
}