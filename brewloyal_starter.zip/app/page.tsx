import Link from "next/link";
export default function Home() {
  return <main className="shell">
    <nav className="nav"><div className="brand">BREW<span>LOYAL</span></div><span className="tag">CAFE LOYALTY PLATFORM</span></nav>
    <section className="hero">
      <p className="eyebrow">TURN EVERY CUP INTO A REASON TO RETURN</p>
      <h1>Good coffee.<br/><em>Great loyalty.</em></h1>
      <p className="intro">Program loyalti digital sederhana untuk cafe modern. Pelanggan kumpulkan stamp, cafe bangun hubungan.</p>
      <div className="actions"><Link className="btn" href="/demo">Lihat demo <span>↗</span></Link><a className="textlink" href="#how">Cara kerja ↓</a></div>
      <div className="card-preview">
        <div className="preview-top"><span>YOUR COFFEE CARD</span><span>01 / 05</span></div>
        <div className="stamps"><b>✓</b><b>✓</b><b>✓</b><i></i><i></i></div>
        <div className="preview-bottom"><strong>3 OF 5 STAMPS</strong><span>2 more to your free drink</span></div>
      </div>
    </section>
    <section id="how" className="features"><p className="eyebrow">BUILT FOR EVERY CAFE</p><h2>Loyal customers,<br/>one scan at a time.</h2><div className="feature-grid">
      <article><small>01</small><h3>Scan & join</h3><p>Pelanggan scan QR cafe dan mendaftar dari HP mereka.</p></article>
      <article><small>02</small><h3>Collect stamps</h3><p>Kasir scan QR pelanggan setiap transaksi yang memenuhi syarat.</p></article>
      <article><small>03</small><h3>Get rewarded</h3><p>Lima stamp ditukar dengan minuman favorit pelanggan.</p></article>
    </div></section>
    <footer>BREWLOYAL © 2026 <span>Built for independent cafes.</span></footer>
  </main>;
}