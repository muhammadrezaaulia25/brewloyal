"use client";
import {useState} from "react";
import {supabase} from "@/lib/supabase";
export default function JoinForm({slug}:{slug:string}){
 const [form,setForm]=useState({name:"",whatsapp:"",birth_date:"",favorite_drink:"",consent:false});
 const [msg,setMsg]=useState(""); const [busy,setBusy]=useState(false);
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setMsg("");
  const {data:cafe,error:ce}=await supabase.from("cafes").select("id,name").eq("slug",slug).eq("active",true).single();
  if(ce||!cafe){setMsg("Cafe tidak ditemukan atau belum aktif.");setBusy(false);return;}
  const {data,error}=await supabase.from("customers").insert({cafe_id:cafe.id,name:form.name,whatsapp:form.whatsapp,birth_date:form.birth_date||null,favorite_drink:form.favorite_drink,whatsapp_consent:form.consent}).select("id").single();
  if(error){setMsg(error.message.includes("customers_cafe_phone")?"Nomor WhatsApp ini sudah terdaftar.":error.message);setBusy(false);return;}
  setMsg("Pendaftaran berhasil! Simpan ID pelanggan: "+data.id);setBusy(false);
 }
 return <form className="form" onSubmit={submit}><label>Nama lengkap<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Nama kamu"/></label><label>Nomor WhatsApp<input required type="tel" value={form.whatsapp} onChange={e=>setForm({...form,whatsapp:e.target.value})} placeholder="62812xxxxxxx"/></label><label>Tanggal lahir<input type="date" value={form.birth_date} onChange={e=>setForm({...form,birth_date:e.target.value})}/></label><label>Minuman favorit<input required value={form.favorite_drink} onChange={e=>setForm({...form,favorite_drink:e.target.value})} placeholder="Contoh: Iced latte"/></label><label className="check"><input type="checkbox" required checked={form.consent} onChange={e=>setForm({...form,consent:e.target.checked})}/> Saya setuju menerima informasi loyalty dan pesan WhatsApp dari cafe ini.</label><button disabled={busy}>{busy?"Menyimpan...":"Daftar sekarang ↗"}</button>{msg&&<p className="status">{msg}</p>}</form>
}