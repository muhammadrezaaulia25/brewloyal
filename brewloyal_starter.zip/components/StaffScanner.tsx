"use client";
import {useEffect,useRef,useState} from "react";
import {supabase} from "@/lib/supabase";
export default function StaffScanner({slug}:{slug:string}){
 const box=useRef<HTMLDivElement>(null);const [result,setResult]=useState("");const [ready,setReady]=useState(false);
 useEffect(()=>{let scanner:any;let mounted=true;(async()=>{const mod=await import("html5-qrcode");if(!mounted||!box.current)return;scanner=new mod.Html5Qrcode("qr-reader");try{await scanner.start({facingMode:"environment"},{fps:10,qrbox:{width:230,height:230}},async(decoded:string)=>{await scanner.stop();setReady(false);await addStamp(decoded);},()=>{});setReady(true);}catch{setResult("Kamera tidak dapat dibuka. Periksa izin kamera browser.");}})();return()=>{mounted=false;try{scanner?.stop().then(()=>scanner.clear()).catch(()=>{});}catch{}}},[]);
 async function addStamp(customerId:string){const {data:cafe}=await supabase.from("cafes").select("id").eq("slug",slug).single();if(!cafe){setResult("Cafe tidak ditemukan.");return;}
  // Production: replace this public demo action with an authenticated server-side RPC restricted to staff.
  const {data,error}=await supabase.rpc("issue_loyalty_stamp",{p_customer_id:customerId,p_cafe_id:cafe.id});
  if(error){setResult("Gagal menambah stamp: "+error.message);return;}
  setResult(data?.message||"Stamp berhasil diproses.");}
 return <div><div id="qr-reader" ref={box} className="scanner"/><p className="muted">{ready?"Arahkan kamera ke QR pelanggan.":"Menyiapkan kamera..."}</p>{result&&<div className="status">{result}</div>}</div>
}